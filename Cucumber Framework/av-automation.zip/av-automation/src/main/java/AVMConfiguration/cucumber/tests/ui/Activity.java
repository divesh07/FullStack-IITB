package AVMConfiguration.cucumber.tests.ui;

public class Activity {
}
