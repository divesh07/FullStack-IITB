package common.actions;

public class Mouse {
}
