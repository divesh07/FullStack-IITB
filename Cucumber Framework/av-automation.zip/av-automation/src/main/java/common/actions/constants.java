package common.actions;

public class constants {

    /*Environment Constants*/
    public static final String ADName = "blrauto";
    public static final String ADExtn = "com";
    public static final String ADUserName = "administrator";
    public static final String ADPassword = "ca$hc0w";
    public static final String VCName = "10.112.19.27";
    public static final String VCUserName = "administrator@vsphere.local";
    public static final String VCPassword = "Ca$hc0w1";
    public static final String Datastore = "[BlrAuto] UEMLUN";
    public static final String ESXName = "10.112.19.19";
    public static final String ESXUserName = "root";
    public static final String ESXPassword = "ca$hc0w";
    public static final String LicenseFilePath = "\\\\10.112.19.26\\Artifacts\\";
    public static final String RemoteDBName = "\\\\10.112.19.84\\SQLExpress";
    public static final String RemoteDBUserName = "sa";
    public static final String RemoteDBPassword = "ca$hc0w";
    public static final String AVloginName = "administrator";
    public static final String AVLoginPwd = "ca$hc0w";
    public static final String DomainControllerHostsList = "10.112.19.21, 10.112.19.107";
    public static final int NumberOfDomainControllersInManualMode = 2;
    public static final int NumberOfDomainControllersInSmartMode = 3;

    public static final String Manager_IP = "http://10.112.19.125:80";
    public static final String Manager_UserName = ADUserName + "\\administrator";
    public static final String Manager_Password = "ca$hc0w";

    public static final String AVMInstallerPath = "C:\\343-master_3x\\Manager\\App Volumes Manager.msi";
    public static final String InstallerWnd = "App Volumes Manager";
    public static final String NextBtn  = "Next>";

    public static final String PathToGeckoDriver = "C:\\Test_Root\\geckodriver.exe";

    public static final int WAITONESECOND = 1;
    public static final int WAITDEFAULTTIME = 40;
    public static final int WAITONEMINUTE = 60;
    public static final int WAITFIVEMINUTE = 300;

    public static final String PathToCurl = "C:\\Test_Root\\bin\\curl\\curl.exe";
}
