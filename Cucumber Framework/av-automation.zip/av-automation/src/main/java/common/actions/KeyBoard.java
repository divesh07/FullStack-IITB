package common.actions;

public class KeyBoard {
}
