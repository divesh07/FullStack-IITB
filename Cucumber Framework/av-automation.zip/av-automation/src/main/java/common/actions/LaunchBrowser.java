package common.actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import common.actions.constants;
import org.openqa.selenium.firefox.FirefoxDriver;

public class LaunchBrowser extends BaseClass{

    public static void LaunchBrowserSession(){
        BaseClass.LaunchFirefox();
    }

}
