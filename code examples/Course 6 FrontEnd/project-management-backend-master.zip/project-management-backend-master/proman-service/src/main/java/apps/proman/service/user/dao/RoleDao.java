package apps.proman.service.user.dao;

import apps.proman.service.common.dao.BaseDao;
import apps.proman.service.user.entity.RoleEntity;

public interface RoleDao extends BaseDao<RoleEntity> {

}
