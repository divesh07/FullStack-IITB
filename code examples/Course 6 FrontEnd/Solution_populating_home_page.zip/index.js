var xhr = new XMLHttpRequest();


function enterTheCode(country){
   var getString = 'https://api.openaq.org/v1/cities?country='+country.value;
   xhr.open('GET', getString);
   xhr.send();
xhr.onreadystatechange = function (){
       if(xhr.readyState === 4 && xhr.status === 200) {
           printStuff();
       }
   }
}

function printStuff(){
   var output = JSON.parse(xhr.response);
   document.getElementById("city-list").innerHTML += "<p>"+output.results[0].city +"</p>"
}
