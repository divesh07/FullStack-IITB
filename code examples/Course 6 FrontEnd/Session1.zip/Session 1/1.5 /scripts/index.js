function signUpSubmit(firstName, lastName, email, password, mobile) {
console.log(firstName.value)
}



