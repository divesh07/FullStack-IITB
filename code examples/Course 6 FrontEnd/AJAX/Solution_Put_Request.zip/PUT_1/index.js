var xhr = new XMLHttpRequest;

function sendPutRequest(name,job){
    var updatedUserData = {
        name : name.value,
        job : job.value
    };
    xhr.open('PUT','https://reqres.in/api/users/2');
    xhr.setRequestHeader("Content-Type", "application/json");

    xhr.send(JSON.stringify(updatedUserData));

    xhr.onreadystatechange = function (){
        if(xhr.readyState === 4 && xhr.status === 200) {
            setInStorage();
        };
    };
};

function setInStorage(){
    var output = xhr.response;
    sessionStorage.setItem("updatedAt",output);

};