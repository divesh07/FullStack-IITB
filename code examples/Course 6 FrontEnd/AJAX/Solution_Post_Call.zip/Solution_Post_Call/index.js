var xhr = new XMLHttpRequest;

function sendPostRequest(name,job){
    var a = {
        name : name.value,
        job : job.value
    }
    xhr.open('POST','https://reqres.in/api/users')
    xhr.setRequestHeader("Content-Type", "application/json")
    xhr.send(JSON.stringify(a));
    xhr.onreadystatechange = function (){
        if(xhr.readyState === 4 && xhr.status === 201) {
            printStuff();
        }
    }
}

function printStuff(){
    var output = xhr.response;
    console.log(output);
}


