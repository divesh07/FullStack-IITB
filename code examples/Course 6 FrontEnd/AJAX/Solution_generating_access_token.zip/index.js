function generateToken(userName,userPassword){
   if(userName.value.length == 0 || userPassword.value.length == 0){
       alert("Please Fill in the Complete Information")
   }
   else{
   var currDate = new Date().toLocaleTimeString();
   var stringToEncode = userName.value+userPassword.value+currDate;
   var accessToken = window.btoa(stringToEncode);
   console.log(accessToken);
   }
}