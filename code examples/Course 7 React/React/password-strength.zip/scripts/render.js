import React from 'react';
import App from "./App.js";
import ReactDOM from 'react-dom';

ReactDOM.render(
    // TODO 6: Render 'App' component here. Add necessary import statement(s) too.
    <App/>,
    document.getElementById('root')
);