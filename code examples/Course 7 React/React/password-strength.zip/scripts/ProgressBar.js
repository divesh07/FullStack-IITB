// TODO 3: Create 'ProgressBar' as a functional component which is initially set at zero progress value. Write necessary import statement(s) too.
import React from 'react';
const ProgressBar = function(){
    return(
        <div>
        <progress value="0" max="100">Very Weak</progress><span>Very Weak</span>
        </div>
    )
}   

export default ProgressBar;
