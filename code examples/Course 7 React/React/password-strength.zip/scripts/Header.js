import React from 'react';

// TODO 1: Create 'Header' as a functional component to display the heading text. Write necessary import statement(s) too.

const Header = function(){
    return(
        <h1>Password Strength Meter</h1>    
    )
}
export default Header;