import React from 'react';

// TODO 2: Create 'Password' as a functional component to render the password input element. Write necessary import statement(s) too.
const Password = function(){
    return(
        <input id="name" type="text" placeholder="Type your password here"/>
    )
}

export default Password;
