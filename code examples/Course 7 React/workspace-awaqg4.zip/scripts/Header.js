// 'Header' as a functional component to display the heading text
// TODO 2: Style Header component using styles written in external stylesheet (external styling)
import React from 'react';
import '../index.css';

const Header = function(){
    return (
        <div id="header">
            <h2>Password Strength Meter</h2>
        </div>
    );
}

export default Header;