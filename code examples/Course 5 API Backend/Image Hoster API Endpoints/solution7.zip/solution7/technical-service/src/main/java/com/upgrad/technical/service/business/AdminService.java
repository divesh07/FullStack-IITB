package com.upgrad.technical.service.business;


import com.upgrad.technical.service.dao.ImageDao;
import com.upgrad.technical.service.dao.UserDao;
import com.upgrad.technical.service.entity.ImageEntity;
import com.upgrad.technical.service.exception.ImageNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AdminService {

    @Autowired
    private ImageDao imageDao;

    public ImageEntity getImage(final String imageUuid) throws ImageNotFoundException {

        ImageEntity imageEntity = imageDao.getImage(imageUuid);
        if (imageEntity == null) {
            throw new ImageNotFoundException("IMG-001", "Image with Uuid not found");
        }
        return imageEntity;
    }
}
