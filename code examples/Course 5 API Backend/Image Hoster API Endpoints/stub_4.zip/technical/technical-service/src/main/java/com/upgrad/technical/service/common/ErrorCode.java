package com.upgrad.technical.service.common;

public interface ErrorCode {

    String getCode();

    String getDefaultMessage();

}