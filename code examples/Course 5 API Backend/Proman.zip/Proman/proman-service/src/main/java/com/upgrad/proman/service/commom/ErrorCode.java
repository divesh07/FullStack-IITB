package com.upgrad.proman.service.commom;

public interface ErrorCode {
    String getCode();

    String getDefaultMessage();
}
