package com.upgrad.ecommerce.domain.v3;

public interface WebObject {
  
  String getUUID();
}