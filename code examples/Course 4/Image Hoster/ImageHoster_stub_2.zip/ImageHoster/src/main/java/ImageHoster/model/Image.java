package ImageHoster.model;
import java.util.Date;

public class Image {

    //id of the image
    private Integer id;

    //title of the image
    private String title;

    //The image in Base64 format
    private String imageFile;

    //Description of the image
    private String description;

    //Date on which the image is posted
    private Date date;

    //Write the constructor for id, title, imageFile, and date

    //Write getter and setter for all the attributes
}
