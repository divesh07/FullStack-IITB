package ImageHoster.service;

import ImageHoster.model.User;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    //We are not currently storing the details of the user anywhere
    //We will be storing the user details in the Database & ORMs part
    public void registerUser(User newUser) {
        return;
    }

}
