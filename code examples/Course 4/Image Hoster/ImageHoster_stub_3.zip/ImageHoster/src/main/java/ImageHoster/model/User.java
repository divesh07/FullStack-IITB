package ImageHoster.model;


public class User {

    private Integer id;
    private String username;
    private String password;
    private UserProfile profile;

   //Genarate getters and setters for all the attributes
}

