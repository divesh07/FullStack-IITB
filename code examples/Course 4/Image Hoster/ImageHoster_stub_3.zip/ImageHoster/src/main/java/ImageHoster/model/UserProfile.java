package ImageHoster.model;


public class UserProfile {

    private Integer id;
    private String fullName;
    private String emailAddress;
    private String mobileNumber;


    //Generate getters and setters for all the attributes
}
