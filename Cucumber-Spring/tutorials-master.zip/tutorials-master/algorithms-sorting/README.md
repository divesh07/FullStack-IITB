## Relevant articles:

- [Bubble Sort in Java](http://www.baeldung.com/java-bubble-sort)
- [Merge Sort in Java](https://www.baeldung.com/java-merge-sort)
- [Quicksort Algorithm Implementation in Java](https://www.baeldung.com/java-quicksort)
- [Insertion Sort in Java](https://www.baeldung.com/java-insertion-sort)
- [Heap Sort in Java](https://www.baeldung.com/java-heap-sort)
