package com.baeldung.sse.jaxrs;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("sse")
public class AppConfig extends Application {
}
