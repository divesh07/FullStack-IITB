## Relevant articles:

- [Introduction to Akka HTTP](https://www.baeldung.com/akka-http)
