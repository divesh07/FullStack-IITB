### Relevant Articles:

- [Introduction to Apache Curator](http://www.baeldung.com/apache-curator)
